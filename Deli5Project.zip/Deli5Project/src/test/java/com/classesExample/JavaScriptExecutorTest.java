package com.classesExample;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class JavaScriptExecutorTest
{
	@Test
	public void JavaScriptLogin() throws InterruptedException
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		JavascriptExecutor java = (JavascriptExecutor)driver;
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com/");
		java.executeScript("document.getElementById('txtUsername').value='Admin';");
		java.executeScript("document.getElementById('txtPassword').value='admin123';");
		Thread.sleep(2000);
		java.executeScript("document.getElementById('btnLogin').click();");
		Thread.sleep(2000);
		java.executeScript("alert('Orange HRM site get opened');");
		Thread.sleep(2000);
		driver.quit();
	}
}
